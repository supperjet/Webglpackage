A Pen created at CodePen.io. You can find this one at http://codepen.io/Yakudoo/pen/rVGraP.

 #holySpaceCowsWeekend
using threejs and tweenmax.
rotate the camera using the mouse