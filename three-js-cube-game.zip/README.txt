A Pen created at CodePen.io. You can find this one at http://codepen.io/chris-creditdesign/pen/emKQwY.

 Click all the boxes to make them explode. Try not to get too dizzy!