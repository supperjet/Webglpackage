A Pen created at CodePen.io. You can find this one at http://codepen.io/kenjiSpecial/pen/vELOrM.

 particle animation with native webgl. 

site:
http://cs.kenji-special.info/

github:
https://github.com/kenjiSpecial/100day-canvas-bootcamp-training