A Pen created at CodePen.io. You can find this one at http://codepen.io/raurir/pen/oXmEPM.

 Racing through two planes of cuboids determined to slide.

Mouse/Touch to zoom in, slide around to change camera angle.