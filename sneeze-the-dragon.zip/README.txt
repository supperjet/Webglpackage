A Pen created at CodePen.io. You can find this one at http://codepen.io/Yakudoo/pen/yNjRRL.

 Help the dragon to make fire, click as fast as possible then release.
A smoke and fire study using ThreeJS and TweenMax.