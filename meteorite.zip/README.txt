A Pen created at CodePen.io. You can find this one at http://codepen.io/Yakudoo/pen/eNmjEv.

 WebGL experiment, using GSAP. Particles are generated and recycled for reuse to optimise performances.