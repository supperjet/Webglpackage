A Pen created at CodePen.io. You can find this one at http://codepen.io/Samsy/pen/emWppX.

 Mutating field from a plane geometry with GLSL Noise + Sombrero shader, thx to Bruno Simon for his previous work, and Ashima for his monster Noise Shader.
Follow me on twitter @Samsyyyy