A Pen created at CodePen.io. You can find this one at http://codepen.io/Yakudoo/pen/BNNGBq.

 WebGL experiment using ThreeJs. Move your mouse right and left, top and bottom to change speed and direction