A Pen created at CodePen.io. You can find this one at http://codepen.io/Astrak/pen/BoBWPB.

 Original galaxy pen, plus a little game to play with the vertex shader. Galaxies transitions made possible with Tweenlite. Tell how many galaxies you saved/destroyed in the comments ;)