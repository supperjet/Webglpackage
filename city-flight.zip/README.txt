A Pen created at CodePen.io. You can find this one at http://codepen.io/Octavector/pen/xhwlG.

 An array of cubes, randomly scaled along the Y axis and placed in a city-like grid fashion. The camera moves forward over the cubes to mimic a flight over a cityscape.