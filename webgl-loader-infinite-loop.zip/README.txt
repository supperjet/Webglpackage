A Pen created at CodePen.io. You can find this one at http://codepen.io/quentinhocde/pen/zGGvgW.

 Made with threejs & greensock (TweenMax)