A Pen created at CodePen.io. You can find this one at http://codepen.io/Francext/pen/yIogq.

 An Abstract Audio Visualizer made with ThreeJS. Drag & drop to change the music, click/touch or leap to change the color. Also mouse wheel to zoom in/out. Works best on Chrome.