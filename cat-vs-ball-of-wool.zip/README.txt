A Pen created at CodePen.io. You can find this one at http://codepen.io/Yakudoo/pen/oXJYxy.

 WebGL Demo using ThreeJs. With inverse kinematics, physics and a lot of cat psychology :)
This cat is a 3D remake of the main character of "Babel, the cat who would be king", a children app I did some time ago. Find it here : http://babeltheking.com/ 
Enjoy!